﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sq",{title:"UI Mbledhës i Ngjyrave",preview:"Parapamje direkte",config:"Hidhni këtë varg në skedën tuaj config.js",predefined:"Setet e paradefinuara të ngjyrave"});